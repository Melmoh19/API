# express_mongo_api
A simple crud api development with express, MongoDB and Node.js
The goal of the project is to show the complete development and design of Application programming interfaces and the middleware operations using Node.js, Express.js
and the Javascript enviroment
